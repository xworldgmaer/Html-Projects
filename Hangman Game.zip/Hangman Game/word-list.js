const wordList = [
    
        {
            word: "guitar",
            hint: "A musical instrument wiht strings."
        },
        {
            word: "piano",
            hint: "A musical instrument with keys."
        },
        {
            word: "violin",
            hint: "A musical instrument with strings."

        },
        {
            word: "astronomy",
            hint: "The scientific study of celestial objects and phenomena"

        },

        {
            word: "painting",
            hint: "The art of applying paint to a surface."
        },

        {
            word: "singing",
            hint: "The act of producing musical sounds with the voice."
        },


        {
            word: "mountain",
            hint: "A natural elevation of the earth's surface."
        },

        {
            word:"dwayneclarke",
            hint: "The Lecture for AI in Comp sci"
        }
];
